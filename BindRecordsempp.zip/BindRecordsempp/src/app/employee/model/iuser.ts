export interface IUser {  
    UserId: number,  
        UserName: string,  
        EmailId: string  
    Gender: string,  
        Address: string,  
        MobileNo: string,  
}